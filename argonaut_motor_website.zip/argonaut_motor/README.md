# Argonaut Motor — Static Website

Website statis untuk dealer motor classic dan cafe racer.

## Isi folder
- `index.html` — struktur halaman
- `styles.css` — tampilan, layout responsif, animasi, dan warna brand
- `script.js` — navigasi mobile, filter koleksi, tahun footer, dan konfigurasi WhatsApp

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser, atau jalankan Live Server dari editor.
3. Gambar dan Google Fonts memakai URL eksternal sehingga koneksi internet diperlukan untuk menampilkannya.

## Kustomisasi penting
- Palet warna berada di bagian `:root` pada `styles.css`.
- Ganti nomor WhatsApp pada variabel `whatsappNumber` di `script.js` dengan format internasional tanpa `+`, contoh `6281234567890`.
- Nama motor, kategori, teks, dan foto contoh dapat diubah langsung di `index.html`.
- Foto yang digunakan adalah gambar eksternal dari Unsplash dan nama/kapasitas motor merupakan konten demo, bukan klaim inventaris aktual.
